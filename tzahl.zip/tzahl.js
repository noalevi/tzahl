(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"RECOVER_Untitled_3_atlas_", frames: [[634,404,300,188],[864,135,53,53],[507,202,53,53],[562,202,53,53],[452,257,42,42],[754,135,53,53],[809,135,53,53],[919,135,53,53],[452,202,53,53],[956,0,53,53],[956,55,53,53],[634,594,53,53],[689,594,53,53],[604,706,300,200],[0,726,300,200],[302,706,300,200],[754,0,200,133],[332,504,300,200],[452,0,300,200],[0,302,330,220],[332,302,300,200],[634,202,300,200],[0,524,300,200],[0,0,450,300]]}
];


// symbols:



(lib._300pxFrefuasvg = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap10 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.חילהאיסוףהקרבי = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.חילהחינוךוהנוער = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.חילהטכנולוגיהוהאחזקה = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.חילהנדסהקרבית = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.חילהקשרוהתקשוב = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.חילהרגלים = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.חילהשיריון = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.חילהתותחנים = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.חילהלוגיסטיקה = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.חילהמשטרההצבאית = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.חילמשאביאנוש = function() {
	this.spriteSheet = ss["RECOVER_Untitled_3_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.totah = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.tech = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.tank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.4,48.5);


(lib.shalish = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.police = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.pic_totah = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהתותחנים();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.866,0.71);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,142);


(lib.pic_tech = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהטכנולוגיהוהאחזקה();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.788,0.688);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,236.4,137.7);


(lib.pic_tank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהשיריון();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.728,0.655);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,240.1,144);


(lib.pic_shalish = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילמשאביאנוש();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.549,0.506);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,247,151.9);


(lib.pic_ragli = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהרגלים();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.817,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,245,144);


(lib.pic_police = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהמשטרההצבאית();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.913,0.844);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,274,168.8);


(lib.pic_medical = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._300pxFrefuasvg();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.798,0.798);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239.4,150);


(lib.pic_logic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהלוגיסטיקה();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.797,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,239.2,144);


(lib.pic_kesher = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהקשרוהתקשוב();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.713,0.63);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,214,126);


(lib.pic_handasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהנדסהקרבית();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,133);


(lib.pic_eisouf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהאיסוףהקרבי();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.813,0.74);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,244,148);


(lib.pic_education = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.חילהחינוךוהנוער();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.711,0.66);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,213.4,132);


(lib.medical = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.logic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.kesher = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.handasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.eisouf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.education = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape.setTransform(74.2,23.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("ArlDoIAAnPIXLAAIAAHPg");
	this.shape_1.setTransform(74.2,23.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFF33").ss(1,1,1).p("ArljnIXLAAIAAHPI3LAAg");
	this.shape_2.setTransform(74.2,23.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,150.3,48.5);


(lib.btn_totah = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AgDErQgdgMgugnQgfgbgPgPQgYgYgPgXQgUgcgWg1IgRgpQgIgVgEgQIADgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAgBAAAAIAFknIHLAFIAAE4QAAAAgBABQAAAAAAABQAAAAgBAAQAAABAAAAQgHAqgYArIAAAAQgTAhgiAsIAAAAQglAugeAZQgpAigpAMIgBAAIgCgBg");
	this.shape.setTransform(30.2,30.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AAAE1IgCgBIAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgegMgwgpQgfgbgPgPQgagagPgXQgUgcgXg3IgRgpQgJgYgEgRQgBgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAIABAAIAFkqQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIHWAFQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQABABAAAAIAAE/QAAABgBAAQAAAAAAABQAAAAAAABQgBAAAAABIgBAAQgHArgZAtIAAAAQgTAhgiAtIAAAAQgmAugfAaQgrAkgsAMIgBAAIgBgBgAjlgEQAAABAAAAQAAAAAAABQgBAAAAABQAAAAAAABIgEAAQAEARAJAVIAQAoQAXA2ATAcQAPAWAZAZQAOAOAgAcQAuAnAdALIACACIAAgBQAqgLAogiQAegaAmgtIAAgBQAigrASghIAAAAQAZgsAHgpQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAIAAk5InMgFg");
	this.shape_1.setTransform(30.1,30.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_tech = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap9();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AAMEqQgdgEgegXQgTgPgggiQgrg0gUgZQgvhAgBgxIAAAAIABgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBIAAlHIGhAAIAAFFIgBABQAAAAAAAAQgBABAAAAQAAABAAAAQAAAAAAABIAAAMIABADIgBACQgJBBgjAyIAAAAQgZAlgoAkQgcAagtAgIAAgBQAAAAABgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAQAAABAAAAQgBABAAAAQgCAGACAFIgBABQgBgBAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAg");
	this.shape.setTransform(29.8,30.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AAKE1QAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBQgegEgegYQgUgPgggjQgsg0gUgaQgxhDgBgzIAAgDQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAIAAgBIAAlJQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAIGrAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAABAAAAQABAAAAABQAAAAAAABIAAFQQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIAAAAIAAAGIgBACIABAEQgKBDgkA0IAAAAQgZAmgpAlQgeAbgxAjIgDABIgBAAIAAABIgEADIgCABIgCAAIgFgBgAjPAbQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIgBAAIAAABQABAxAvA/QAUAaArAzQAgAjATAOQAeAXAdAEQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABIABgBQgCgFACgGQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQgBABAAAAIAAACQAtghAcgZQAogkAZglIAAAAQAjgzAJhBIABgCIgBgCIAAgNQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAIABgBIAAlEImhAAg");
	this.shape_1.setTransform(29.8,30.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_tank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap11();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.094,1.094);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AhIEDQg6grgog+Qgog+gOhHIAAgDIgDgBQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIgFkrIABgCIACgCIACgBIG8ADIADAAIgBABQgBABAAAAQAAAAAAABQgBAAAAABQAAAAAAABIADDPIgBACIABAHIgBACIACBFIAAACIAAABIgCAAQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABIgCADIAAAAIAAAFIAAABIAAADIACADIAEAEIABADQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIADgBIABAAQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBIAAgCIABAAIABgDIAEgBIABgBQAEAfgVArQgVApgmAqQgXAbgwAtQgSARgKAHQgQAMgRAEIAAABQgJACgJAAQglAAgrghgAjhAEQgBAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIACACIAAABIABACQAAAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAAABABAAQAAAAAAAAQABABAAAAQABAAAAAAIADgBIABgBQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgEgCgEIgBAAIgDgEIgBgBIgDgBQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABg");
	this.shape.setTransform(28.8,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("ADXCfIgBgCIgEgEIgCgDIAAgEIAAgBIAAgEIAAAAIACgEQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAIACAAIAAgCIAAgBIgChHIABgBIgBgHIABgDIgDjOQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAIABgBIACgBQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABIABAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABIAAAKIgBABIABACQAFC4ABBdIAAACIAAABIAAABIgBACIAAADIgBADIgBABIgEABIgBACIgBABIAAACQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAIgBABIgDABQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBAAAAgBgAjgCUQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIgBgCIAAAAIgCgDQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAIADABIABAAIADAEIABAAQACAEAAAEQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAABIgBABIgDAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAg");
	this.shape_1.setTransform(29.2,15.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,58,58);


(lib.btn_shalish = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AACE7QgZgKgagVQgTgPgZgcIAAAAQgcgdgWgZQhJhTgIhQIABgBQABgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBIAAlJIG3gFIAFFEQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABIAAAAIgCADQgHAigSAoQgNAbgYArIgBABQgQAhgUAWQgSAUgoAcIAAgBQgtAegQASQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAABIABABIgCgBg");
	this.shape.setTransform(30.8,30.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AAAFFQgbgKgcgXIAAAAQgTgPgZgdIgBAAQgcgcgWgaQhMhWgHhUQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIACgCIAAlNQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAgBQABAAAAAAQAAAAABgBQAAAAABAAQAAAAABAAIHBgFQABAAAAAAQABAAAAAAQABABAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAAAABIAFFJQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgBABIABABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgHAjgTApQgNAcgZAsIAAAAQgRAigVAXQgSAVgqAcIAAABQgrAcgQARQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgBgBIAAAEQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgCABIgBAAgAjck1IAAFJQAAAAAAABQAAAAgBABQAAAAAAABQAAAAgBAAIgBABQAIBRBJBTQAVAZAdAcIAAABQAZAbATAQQAaAVAYAJIACABIAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQARgRAsgeIAAAAQApgcARgTQAVgWAQgiIAAAAQAZgsANgbQASgnAHgjIACgCIAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgFlEg");
	this.shape_1.setTransform(30.7,30.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_ragli = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap12();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("Ag6EEQgrghgSgSIAAAAQgfgjgagyQgRgigYg+IAEgCQAAAAAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBIAAlMIGpAAIACFYQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAIACABIgBACQgbBvhRBPQgsAsg8AdQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAAAABIAAAAIgBABIgBAAIgBABQgTgUgngeg");
	this.shape.setTransform(30.3,30.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AgBFAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQgSgTgpggQgrghgSgTIgBAAQgggjgag0QgSgigYg/QAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAIACAAIAAgCIAAlQQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAAAABgBQAAAAABAAQAAAAABAAIGyAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAABAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAABIACFdIgBADIACACQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgcByhSBQQgtAtg8AeIAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAIgCABIAAAAIgDABIgDABIgCABIAAAAgAg6EDQAoAeASAUIABAAIABgBIABgBIAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABgBQA8gdAsgsQBQhOAbhwIABgCIgBgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAAAgBIgClYImoAAIAAFLQAAABgBAAQAAABAAAAQAAABAAAAQgBABAAAAIgDABQAYA/ARAhQAZAzAgAiIAAAAQARASArAhg");
	this.shape_1.setTransform(30.3,30.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_police = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap13();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.429,1.429);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF99").ss(1,1,1).p("Ak2lAIJtAAIAAGUIhpDtImHgFIh7jtg");
	this.shape.setTransform(29.4,28.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFF99").s().p("Ai5E8Ih7jtIgCmPIJtAAIAAGUIhpDtg");
	this.shape_1.setTransform(29.4,28.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_medical = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap7();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AgEExIgBgBQgDgBgFgFIgCgBIgWgIQgIgEgPgPIAAAAIgUgXQgIgJgHgFQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgvgQgehKQgnhegGiJQgEhtAPhlIAAAAIADABIGeAAIACgBQAJAxACA9QACAqgDBJIAAABQgBA5gDAdQgFAwgNAkQgXBCg8BBQgVAZgSANIAAAAQgXAQgXABQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAABABAAIAAAAIAAABIAAAGQgGABgMAHQgHADgDAAIgDAAg");
	this.shape.setTransform(30.3,28.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AgIE5QgEgBgHgGIgWgJQgJgDgRgSIgBAAIgUgXIgNgNIgBAAIgHgFIgCgDQgsgUgehHIABAAQgohggGiKQgEhvAPhlQAAgBAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAABgBQAAAAABAAQAAAAABAAIACABIABgDQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAIGeAAIADABIACgBQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAKAzACBAQACArgDBKQgBA5gDAeQgFAxgOAmQgXBCg9BEQgXAagSAMIAAAAQgXARgWACIAAAMQAAAAAAABQgBAAAAABQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgDgBIgQAHQgIAFgGAAQgEAAgDgCgAjRkwQgPBlAEBtQAGCIAnBfQAeBJAvARQAAAAABAAQAAAAAAAAQABABAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAHAFAIAIIAUAXIAAABQAPAPAIADIAWAJIACABQAFAFADABIABAAQAEACAJgFQAMgGAGgCIAAgFIAAgBIAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQAAAAABAAQAAAAABAAQAXgBAXgRIAAAAQASgMAVgZQA8hCAXhBQANgkAFgwQADgeABg5IAAAAQADhJgCgqQgCg9gJgxIgCAAImeAAIgDAAg");
	this.shape_1.setTransform(30.3,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_logic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap10();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AgkEsQgrgRgmgtQgWgagig4IACgCQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBIgBgBIACgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQgOgOgJgWQgGgOgIgbQgPg4gDglQgDgYACggIADg4QAEhXgJhIIACABIG4gFIADgBQAbCzghC6QgOBRgqAVQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAAAIAAAFQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAAAIABAAQgWAdggAbQgbAXgxAjQgRAMgJACIAAAAIgKABQgLAAgPgGg");
	this.shape.setTransform(30.7,30);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AgoE1QgtgSgngvQgYgcglg+IAAAAIgBgDQgBAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAIACABQgNgPgJgWQgHgPgHgcQgQg5gDglQgDgaACggIADg4QAEhWgJhHQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAIACABIAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgBAAAAQABAAAAAAIG4gFQAAAAABAAQAAAAAAABQABAAAAAAQABAAAAABIAAAAIADgCQABAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAcC2ghC9QgNBJgiAcIABACQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQgZAlgoAjQgcAYgyAiQgSANgLADQgFACgHAAQgNAAgRgHgAjfiOIgDA5QgCAfADAZQADAkAPA4QAIAcAGAOQAJAWAOAOQAAAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAAAABIgCABIABABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgCACQAiA4AWAbQAmAsArASQAVAIAPgDIAAAAQAJgDARgMQAxgiAbgXQAggcAWgcIgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAIAAgFQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAQAqgVAOhRQAhi6gbi0IgDABIm4AFIgCAAQAJBIgEBWgACgCqIAAABIABgBIgBAAg");
	this.shape_1.setTransform(30.7,30.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_kesher = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap8();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF99").ss(1,1,1).p("AFDAAQAACGheBfQhfBeiGAAQiFAAheheQhfhfAAiGQAAiFBfheQBehfCFAAQCGAABfBfQBeBeAACFg");
	this.shape.setTransform(36.9,30.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFF99").s().p("AjkDkQheheAAiGQAAiFBehfQBfheCFAAQCGAABfBeQBeBfAACFQAACGheBeQhfBfiGAAQiFAAhfhfg");
	this.shape_1.setTransform(36.9,30.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{x:0}}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance,p:{x:7}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_handasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap6();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AhqDyIAAAAQgugzgZgkQgigzgQgxQgPgsgEg5QgCgfAAhNIADiIIABAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBIAAgKIG/AAIACAAIgBABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAgBQAIgDAGAIQAHAJAAANIAAAAQAEAyAFBhQAHBegNA4QgOA7gtA+QgdApg+BAQgYAZgNAJQgVAQgVADIgKABQgwAAg7hAg");
	this.shape.setTransform(30.9,29.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AhyD5IAAgBQgugzgZglIAAAAQgkg0gPgyQgQgtgEg7QgCgfAAhNIADiKQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAQAAAAABAAIABAAIAAgIQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAIACgBIAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAIHBAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAIAAACQAOgGALAPQAJALAAAQIAAABQAEAyAFBgQAHBggNA5IAAAAQgOA9gvBAQgdApg/BBQgZAZgNAKQgYARgXAEIgLABQg0AAg/hDgAALExQAVgDAVgQQANgJAYgZQA+hAAdgpQAtg+AOg7QANg4gHhfQgFhggEgyIAAAAQAAgNgHgJQgGgJgIAEQAAAAgBAAQAAABgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIABgBIgCAAIm/AAIAAAKQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAIgBAAIgDCIQAABNACAeQAEA6APAsQAQAwAiAzQAZAlAuAzIAAAAQBBBGA0gHg");
	this.shape_1.setTransform(30.9,29.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_eisouf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("AAOEoIgDAAIgJAAIgBAAQhNgkg8hBQg7hAgchPIAAgBIgDgGIAAgBIgFlTIHLAFIAEFKQgcBRg5BCQg5BDhMAqg");
	this.shape.setTransform(30.4,30.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AAAEyQhRglg+hEQg9hBgchRIAAAAIgBgBIgCgCQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBIgFleIABgCIABgCIADgBIHVAFQABAAAAABQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAIAEFQIAAACQgdBUg6BEQg7BEhNArQgBAAAAAAQgBAAAAABQgBAAAAgBQgBAAAAAAIgBAAIgDAAIgGAAIgBABIgCABIgCgBgAjiArIAAACIADAGIAAAAQAcBPA7BAQA8BCBNAjIABAAIAJAAIACABIABAAQBMgqA5hDQA5hCAchSIgElKInLgFg");
	this.shape_1.setTransform(30.4,30.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_education = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Bitmap14();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.132,1.132);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFF99").s().p("Ag8EbQgpghgig2IAAAAQgZgpgbhCIAAAAIgihVIACgBQABgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAAAIAFk2IGyAAIgDFJIABACQgVA+goBHQhGCChaAXIgDACIgBgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBABIgCACQgZgKgYgSg");
	this.shape.setTransform(30.4,30.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AgFFCQgggLgcgWQgrghgjg4IAAAAQgagqgbhCIAAAAQgNgfgWg5QAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAQABgBAAAAQABAAAAAAIABgBIAFk7QAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABgBAAAAIG8AAQABAAAAABQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAIgCFPQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgWBAgnBIQhKCHheAXIgBAAIAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBAAQAAABgBAAIgCABIgBgBgAg7EZQAXASAaAKIACgCQAAAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAIACABIACgCQBagXBHiCQAnhGAVg/IAAgCIAClJImyAAIgFE2QAAABAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgDABIAiBWIABAAQAaBCAaApIAAAAQAhA2AqAgg");
	this.shape_1.setTransform(30.3,30.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


// stage content:
(lib.RECOVER_Untitled3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var self = this;
		var counter = 0;
		self.pic_handasa.visible = false;
		self.pic_kesher.visible = false;
		self.pic_ragli.visible = false;
		self.pic_tank.visible = false;
		self.pic_totah.visible = false;
		self.pic_police.visible = false;
		self.pic_eisouf.visible = false;
		self.pic_logic.visible = false;
		self.pic_medical.visible = false;
		self.pic_shalish.visible = false;
		self.pic_education.visible = false;
		self.pic_tech.visible = false;
		
		
		//חיל הנדסה
		self.btn_handasa.addEventListener("mouseover", over_handasa);
		self.btn_handasa.addEventListener("mouseout", out_handasa);
		self.btn_handasa.addEventListener("click", click_handasa);
		
		
		function over_handasa() {
			self.pic_handasa.visible = true;
			self.handasa.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה"
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		
		}
		
		function out_handasa() {
			self.pic_handasa.visible = false;
			self.handasa.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		
		}
		function click_handasa() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_handasa.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל ההנדסה\n הוקם בשנת: 1948 מוטו: ראשונים תמיד לך בעקבות הכסופים, חברים לכל החיים \n פעילות עיקרית: פריצת מכשולים, פירוק מוקשים, הטמנת מטענים, יצירת מכשולים לאויב, מתפקדת כיחידת חיר בשגרה ובחירום. \n יחידה מובחרת: יהלם"
		
		
		
		}
		
		self.handasa.addEventListener("mouseover", overhandasa);
		self.handasa.addEventListener("mouseout", outhandasa);
		self.handasa.addEventListener("click", clickhandasa);
		
		function overhandasa() {
			self.pic_handasa.visible = true;
			self.btn_handasa.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		
		}
		function outhandasa() {
			self.pic_handasa.visible = false;
			self.btn_handasa.gotoAndStop(0);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		}
		function clickhandasa() {
			counter++
			self.more_info.text = "";
			self.pic_handasa.visible = false;
			self.h1.visible = false;
			self.h2.visible = false;
			self.info.text = "חיל ההנדסה\n הוקם בשנת: 1948 מוטו: ראשונים תמיד לך בעקבות הכסופים, חברים לכל החיים \n פעילות עיקרית: פריצת מכשולים, פירוק מוקשים, הטמנת מטענים, יצירת מכשולים לאויב, מתפקדת כיחידת חיר בשגרה ובחירום. \n יחידה מובחרת: יהלם"
		}
		
		self.btn_ragli.addEventListener("mouseover", over_ragli);
		self.btn_ragli.addEventListener("mouseout", out_ragli);
		self.btn_ragli.addEventListener("click", click_ragli);
		
		function over_ragli() {
			self.pic_ragli.visible = true;
			self.ragli.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_ragli() {
			self.pic_ragli.visible = false;
			self.ragli.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		}
		
		function click_ragli() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_ragli.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל רגלים- שנת הקמה- 1948 \n מוטו: - \nפעילות עיקרית- בהובלת הלחימה על ידי לוחמי החי''ר נגד כוחות גרילה ופעילויות טרור בשגרה ובחירום. הלוחמים פועלים בשטחים מורכבים ונעים באופן רגלי, רכוב, מוסק ומוטס לביצוע המשימות. \nיחידות מובחרות- גדס''ר גולני, דובדבן, גדס''ר נחל, מגלן, גדס''ר צנחנים, שמשון, עוקץ וסיירת מטכ''ל.  "
		}
		//חיל הרגלים
		self.ragli.addEventListener("mouseover", overragli);
		self.ragli.addEventListener("mouseout", outragli);
		self.ragli.addEventListener("click", clickragli);
		
		function overragli() {
			self.pic_ragli.visible = true;
			self.btn_ragli.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outragli() {
			self.pic_ragli.visible = false;
			self.btn_ragli.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickragli() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_ragli.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל רגלים- שנת הקמה- 1948 \n מוטו: - \nפעילות עיקרית- בהובלת הלחימה על ידי לוחמי החי''ר נגד כוחות גרילה ופעילויות טרור בשגרה ובחירום. הלוחמים פועלים בשטחים מורכבים ונעים באופן רגלי, רכוב, מוסק ומוטס לביצוע המשימות. \nיחידות מובחרות- גדס''ר גולני, דובדבן, גדס''ר נחל, מגלן, גדס''ר צנחנים, שמשון, עוקץ וסיירת מטכ''ל.  "
		}
		//חיל התותחנים
		self.btn_tank.addEventListener("mouseover", over_tank);
		self.btn_tank.addEventListener("mouseout", out_tank);
		self.btn_tank.addEventListener("click", click_tank);
		
		function over_tank() {
			self.pic_tank.visible = true;
			self.tank.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_tank() {
			self.pic_tank.visible = false;
			self.tank.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_tank() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_tank.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל שריון \n  בשנת 1948\nמוטו- 'האדם שבטנק ינצח'\n פעילות עיקרית: החיל המכריע בזרוע היבשה אשר מבסס את פעולתו על שילוב של ניידות, עמידות וכוח אש. בימי שלום מתפקד החיל כחיל חי''ר בביצוע משימות ביטחון שוטף. \n יחידה מובחרת- פלס''ר שריון ";
		}
		
		self.tank.addEventListener("mouseover", overtank);
		self.tank.addEventListener("mouseout", outtank);
		self.tank.addEventListener("click", clicktank);
		
		function overtank() {
			self.pic_tank.visible = true;
			self.btn_tank.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outtank() {
			self.pic_tank.visible = false;
			self.btn_tank.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clicktank() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_tank.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל שריון \n  בשנת 1948\nמוטו- 'האדם שבטנק ינצח'\n פעילות עיקרית: החיל המכריע בזרוע היבשה אשר מבסס את פעולתו על שילוב של ניידות, עמידות וכוח אש. בימי שלום מתפקד החיל כחיל חי''ר בביצוע משימות ביטחון שוטף. \n יחידה מובחרת- פלס''ר שריון ";
		}
		//חיל התותחנים
		self.btn_totah.addEventListener("mouseover", over_totah);
		self.btn_totah.addEventListener("mouseout", out_totah);
		self.btn_totah.addEventListener("click", click_totah);
		
		function over_totah() {
			self.pic_totah.visible = true;
			self.totah.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_totah.visible = true;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_totah() {
			self.pic_totah.visible = false;
			self.totah.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.pic_totah.visible = false;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_totah() {
		clicktotah()	
		}
		
		self.totah.addEventListener("mouseover", overtotah);
		self.totah.addEventListener("mouseout", outtotah);
		self.totah.addEventListener("click", clicktotah);
		
		function overtotah() {
			self.pic_totah.visible = true;
			self.h1.visible = false;
			self.h2.visible = false;
			self.btn_totah.gotoAndStop(1);
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outtotah() {
			self.pic_totah.visible = false;
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_totah.gotoAndStop(0);
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clicktotah() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_totah.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל תותחנים\n הוקם ב-12 למרץ 1948 \n מוטו- 'תחכום ועוצמה' \nפעילות עיקרית: אמון על הפעלת האש ביבשה. החיל מפעיל מערכי נשק מתקדמים לעומק שטח האויב, המעניקים חיפוי אש וסיוע לכוח המתמרן. ובנוסף אחראי על מערכות ארטילריה לטווח בינוני וארוך. \nיחידה מובחרת- מיתר (פורקה בינואר 2017)";
		}
		//חיל איסוף
		self.btn_eisouf.addEventListener("mouseover", over_eisouf);
		self.btn_eisouf.addEventListener("mouseout", out_eisouf);
		self.btn_eisouf.addEventListener("click", click_eisouf);
		
		function over_eisouf() {
			self.pic_eisouf.visible = true;
			self.eisouf.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_eisouf() {
			self.pic_eisouf.visible = false;
			self.eisouf.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_eisouf() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_eisouf.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל איסוף קרבי \nהוקם באפריל 2000 \nמוטו- 'הצופה שלפני המחנה'\nפעילות עיקרית- הינו מערך אשר הוקם בכדי להוות גוף אחוד אשר יתכלל בצורה מסונכרנת את כל נושא הביטחון השוטף וההגנה על גבולות המדינה בכל הקשור לתצפיות, איסוף מידע מודיעיני ואיתור חדירות אויב.";
		}
		
		self.eisouf.addEventListener("mouseover", overeisouf);
		self.eisouf.addEventListener("mouseout", outeisouf);
		self.eisouf.addEventListener("click", clickeisouf);
		
		function overeisouf() {
			self.pic_eisouf.visible = true;
			self.btn_eisouf.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outeisouf() {
			self.pic_eisouf.visible = false;
			self.btn_eisouf.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickeisouf() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_eisouf.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל איסוף קרבי \nהוקם באפריל 2000 \nמוטו- 'הצופה שלפני המחנה'\nפעילות עיקרית- הינו מערך אשר הוקם בכדי להוות גוף אחוד אשר יתכלל בצורה מסונכרנת את כל נושא הביטחון השוטף וההגנה על גבולות המדינה בכל הקשור לתצפיות, איסוף מידע מודיעיני ואיתור חדירות אויב.";
		}
		//חיל לוגיסטיקה
		self.btn_logic.addEventListener("mouseover", over_logic);
		self.btn_logic.addEventListener("mouseout", out_logic);
		self.btn_logic.addEventListener("click", click_logic);
		
		function over_logic() {
			self.pic_logic.visible = true;
			self.logic.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_handasa.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_logic() {
			self.pic_logic.visible = false;
			self.logic.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_handasa.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_logic() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_logic.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הלוגיסטיקה \nהוקם בשנת 1975 \nמוטו: -\nפעילות עיקרית: אחראי בחירום על המענה הלוגיסטי לכל היחידה, מאחר והמפקד מתרכז בלחימה וכיבוש היעד. חיל הלוגיסטיקה מתאם את תחום ההספקה, הרפואה, האחזקה, טיפול בכוח אדם, רבנות וככל שעולים בסולם הדרגות כך גדלה אחריותו.";
		}
		//חיל 
		self.logic.addEventListener("mouseover", overlogic);
		self.logic.addEventListener("mouseout", outlogic);
		self.logic.addEventListener("click", clicklogic);
		
		function overlogic() {
			self.pic_logic.visible = true;
			self.btn_logic.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_handasa.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outlogic() {
			self.pic_logic.visible = false;
			self.btn_logic.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_handasa.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clicklogic() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_logic.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הלוגיסטיקה \nהוקם בשנת 1975 \nמוטו: -\nפעילות עיקרית: אחראי בחירום על המענה הלוגיסטי לכל היחידה, מאחר והמפקד מתרכז בלחימה וכיבוש היעד. חיל הלוגיסטיקה מתאם את תחום ההספקה, הרפואה, האחזקה, טיפול בכוח אדם, רבנות וככל שעולים בסולם הדרגות כך גדלה אחריותו.";
		}
		//חיל הרפואה
		self.btn_medical.addEventListener("mouseover", over_medical);
		self.btn_medical.addEventListener("mouseout", out_medical);
		self.btn_medical.addEventListener("click", click_medical);
		
		function over_medical() {
			self.pic_medical.visible = true;
			self.medical.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_medical() {
			self.pic_medical.visible = false;
			self.medical.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_medical() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_medical.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הרפואה\nהוקם ב1947 על בסיס מערך הרפואה של ההגנה\nמוטו- 'חיל הרפואה נלחם על חייך!'\nפעילות עיקרית- החיל עוסק בקביעת מדיניות הטיפול הרפואי ותורת הסיוע הרפואי לכל הדרגים. מתן טיפול רפואי מיטבי לחיילי צה''ל, במלחמה, בביטחון שוטף ובשגרה, בקידום הבריאות בצה''ל, ובקידום הרפואה הצבאית.";
		}
		
		self.medical.addEventListener("mouseover", overmedical);
		self.medical.addEventListener("mouseout", outmedical);
		self.medical.addEventListener("click", clickmedical);
		
		function overmedical() {
			self.pic_medical.visible = true;
			self.btn_medical.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outmedical() {
			self.pic_medical.visible = false;
			self.btn_medical.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickmedical() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_medical.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הרפואה\nהוקם ב1947 על בסיס מערך הרפואה של ההגנה\nמוטו- 'חיל הרפואה נלחם על חייך!'\nפעילות עיקרית- החיל עוסק בקביעת מדיניות הטיפול הרפואי ותורת הסיוע הרפואי לכל הדרגים. מתן טיפול רפואי מיטבי לחיילי צה''ל, במלחמה, בביטחון שוטף ובשגרה, בקידום הבריאות בצה''ל, ובקידום הרפואה הצבאית.";
		}
		//חיל תקשוב וקשר
		self.btn_kesher.addEventListener("mouseover", over_kesher);
		self.btn_kesher.addEventListener("mouseout", out_kesher);
		self.btn_kesher.addEventListener("click", click_kesher);
		
		function over_kesher() {
			self.pic_kesher.visible = true;
			self.kesher.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_kesher() {
			self.pic_kesher.visible = false;
			self.kesher.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_kesher() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_kesher.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הקשר והתקשוב \nהוקם בשנת 1948 \nמוטו: -\nפעילות עיקרית: החיל אחראי על כל הפעלת הקשר, המחשבים והתקשורת של הכוחות בצה''ל בשדה הקרב ובזרועות השונות. אמונם על פיתוח תוכנה, הצפנה, הגנת הרשת תקשורת לווינים והקשר בשדה הקרב. ";
		}
		
		self.kesher.addEventListener("mouseover", overkesher);
		self.kesher.addEventListener("mouseout", outkesher);
		self.kesher.addEventListener("click", clickkesher);
		
		function overkesher() {
			self.pic_kesher.visible = true;
			self.btn_kesher.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outkesher() {
			self.pic_kesher.visible = false;
			self.btn_kesher.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickkesher() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_kesher.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הקשר והתקשוב \nהוקם בשנת 1948 \nמוטו: -\nפעילות עיקרית: החיל אחראי על כל הפעלת הקשר, המחשבים והתקשורת של הכוחות בצה''ל בשדה הקרב ובזרועות השונות. אמונם על פיתוח תוכנה, הצפנה, הגנת הרשת תקשורת לווינים והקשר בשדה הקרב. ";
		}
		//חיל חינוך
		self.btn_education.addEventListener("mouseover", over_education);
		self.btn_education.addEventListener("mouseout", out_education);
		self.btn_education.addEventListener("click", click_education);
		
		function over_education() {
			self.pic_education.visible = true;
			self.education.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_education() {
			self.pic_education.visible = false;
			self.education.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_education() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_education.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל החינוך והנוער \nהוקם בשנת 1984 \nמוטו: - \nפעילות עיקרית: החיל עוסק בעשייה חינוכית פיקודית, ובמשימות שמטרתן חיזוק הקשר בין הצבא לחברה וטיפוח ההבנה והזיקה של ערכי רוח צה''ל בקרב חיילים ומפקדים.";
		}
		
		self.education.addEventListener("mouseover", overeducation);
		self.education.addEventListener("mouseout", outeducation);
		self.education.addEventListener("click", clickeducation);
		
		function overeducation() {
			self.pic_education.visible = true;
			self.btn_education.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outeducation() {
			self.pic_education.visible = false;
			self.btn_education.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		}
		
		function clickeducation() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_education.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל החינוך והנוער \nהוקם בשנת 1984 \nמוטו: - \nפעילות עיקרית: החיל עוסק בעשייה חינוכית פיקודית, ובמשימות שמטרתן חיזוק הקשר בין הצבא לחברה וטיפוח ההבנה והזיקה של ערכי רוח צה''ל בקרב חיילים ומפקדים.";
		}
		//חיל משטרה צבאית
		self.btn_police.addEventListener("mouseover", over_police);
		self.btn_police.addEventListener("mouseout", out_police);
		self.btn_police.addEventListener("click", click_police);
		
		function over_police() {
			self.pic_police.visible = true;
			self.police.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_police() {
			self.pic_police.visible = false;
			self.police.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_police() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_police.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל המשטרה הצבאית\nהוקם בשנת 1948\nמוטו: -\nפעילות עיקרית: הפעילות בחיל מכילה שמירה על חיי אדם, דרך הגנה על הגבולות, ליווי צמוד של כוחות לוחמים, תפיסת משתמטים משירות, אכיפת משמעת ותעבורה, שמירה על כלואי צה''ל, חקירות בילוש והמעברים. ";
		}
		
		self.police.addEventListener("mouseover", overpolice);
		self.police.addEventListener("mouseout", outpolice);
		self.police.addEventListener("click", clickpolice);
		
		function overpolice() {
			self.pic_police.visible = true;
			self.btn_police.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outpolice() {
			self.pic_police.visible = false;
			self.btn_police.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickpolice() {
			click_police()
		}
		//חיל טכנולוגיה
		self.btn_tech.addEventListener("mouseover", over_tech);
		self.btn_tech.addEventListener("mouseout", out_tech);
		self.btn_tech.addEventListener("click", click_tech);
		
		function over_tech() {
			self.pic_tech.visible = true;
			self.tech.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function out_tech() {
			self.pic_tech.visible = false;
			self.tech.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_tech() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_tech.visible = false;
			self.more_info.text = "";
			self.info.text = "חיל הטכנולוגיה והאחזקה\nהוקם בשנת 1941\nמוטו: - \nפעילות עיקרית- חיל הטכנולוגיה והאחזקה הוא חיל תומך לחימה. החיל מורכב משני מערכים עיקריים: המערך הטכני והמערך ההנדסי. המערך הטכני מורכב מבעלי מקצוע המתחזקים, מטפלים ומתקנים את ציוד הלחימה ואת הציוד המסייע ללחימה הנמצאים בשימוש זרוע היבשה בצה''ל";
		}
		
		self.tech.addEventListener("mouseover", overtech);
		self.tech.addEventListener("mouseout", outtech);
		self.tech.addEventListener("click", clicktech);
		
		function overtech() {
			self.pic_tech.visible = true;
			self.btn_tech.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_shalish.alpha = 0.5;
			self.info.text = "";
		}
		function outtech() {
			self.pic_tech.visible = false;
			self.btn_tech.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_shalish.alpha = 1;
			self.info.text = "";
		
		}
		
		function clicktech() {
			click_tech()
		}
		//חיל משאבי אנוש
		self.btn_shalish.addEventListener("mouseover", over_shalish);
		self.btn_shalish.addEventListener("mouseout", out_shalish);
		self.btn_shalish.addEventListener("click", click_shalish);
		
		function over_shalish() {
			self.pic_shalish.visible = true;
			self.shalish.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על סמל היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.info.text = "";
		}
		function out_shalish() {
			self.pic_shalish.visible = false;
			self.shalish.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.info.text = "";
		
		}
		
		function click_shalish() {
			counter++
			self.h1.visible = false;
			self.h2.visible = false;
			self.pic_shalish.visible = false;
			self.more_info.text = "";
			self.info.text ="חיל משאבי האנוש \nהוקם בשנת 1977\nמוטו: -\nפעילות עיקרית: תחומי העיסוק של החיל הם בכל הקשור למיצוי, פיתוח וטיפוח כוח האדם.";
		}
		
		self.shalish.addEventListener("mouseover", overshalish);
		self.shalish.addEventListener("mouseout", outshalish);
		self.shalish.addEventListener("click", clickshalish);
		
		function overshalish() {
			self.pic_shalish.visible = true;
			self.btn_shalish.gotoAndStop(1);
			self.h1.visible = false;
			self.h2.visible = false;
			self.more_info.text = "לעוד מידע לחץ על שם היחידה";
			self.btn_logic.alpha = 0.5;
			self.btn_tech.alpha = 0.5;
			self.btn_medical.alpha = 0.5;
			self.btn_eisouf.alpha = 0.5;
			self.btn_totah.alpha = 0.5;
			self.btn_kesher.alpha = 0.5;
			self.btn_tank.alpha = 0.5;
			self.btn_ragli.alpha = 0.5;
			self.btn_police.alpha = 0.5;
			self.btn_education.alpha = 0.5;
			self.btn_handasa.alpha = 0.5;
			self.info.text = "";
		}
		function outshalish() {
			self.pic_shalish.visible = false;
			self.btn_shalish.gotoAndStop(0);
			self.h1.visible = true;
			self.h2.visible = true;
			self.more_info.text = "";
			self.btn_logic.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_medical.alpha = 1;
			self.btn_eisouf.alpha = 1;
			self.btn_totah.alpha = 1;
			self.btn_kesher.alpha = 1;
			self.btn_tank.alpha = 1;
			self.btn_ragli.alpha = 1;
			self.btn_police.alpha = 1;
			self.btn_education.alpha = 1;
			self.btn_tech.alpha = 1;
			self.btn_handasa.alpha = 1;
			self.info.text = "";
		
		}
		
		function clickshalish() {
			click_shalish()
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// FlashAICB
	this.txt_eisouf = new cjs.Text("חיל האיסוף הקרבי", "17px 'Alef'", "#E6C833");
	this.txt_eisouf.name = "txt_eisouf";
	this.txt_eisouf.textAlign = "center";
	this.txt_eisouf.lineHeight = 25;
	this.txt_eisouf.lineWidth = 143;
	this.txt_eisouf.parent = this;
	this.txt_eisouf.setTransform(404,687.9);

	this.info = new cjs.Text("", "22px 'Alef'", "#E6C833");
	this.info.name = "info";
	this.info.textAlign = "center";
	this.info.lineHeight = 32;
	this.info.lineWidth = 390;
	this.info.parent = this;
	this.info.setTransform(478.1,149.1);

	this.pic_tank = new lib.pic_tank();
	this.pic_tank.name = "pic_tank";
	this.pic_tank.parent = this;
	this.pic_tank.setTransform(373.5,404.2);
	new cjs.ButtonHelper(this.pic_tank, 0, 1, 1);

	this.pic_police = new lib.pic_police();
	this.pic_police.name = "pic_police";
	this.pic_police.parent = this;
	this.pic_police.setTransform(489,478.6,0.911,0.882,0,0,0,137.2,84.4);
	new cjs.ButtonHelper(this.pic_police, 0, 1, 1);

	this.pic_totah = new lib.pic_totah();
	this.pic_totah.name = "pic_totah";
	this.pic_totah.parent = this;
	this.pic_totah.setTransform(489.9,482.2,0.932,1.026,0,0,0,129.9,71);
	new cjs.ButtonHelper(this.pic_totah, 0, 1, 1);

	this.pic_shalish = new lib.pic_shalish();
	this.pic_shalish.name = "pic_shalish";
	this.pic_shalish.parent = this;
	this.pic_shalish.setTransform(485.5,480.1,1,1,0,0,0,123.5,75.9);
	new cjs.ButtonHelper(this.pic_shalish, 0, 1, 1);

	this.pic_ragli = new lib.pic_ragli();
	this.pic_ragli.name = "pic_ragli";
	this.pic_ragli.parent = this;
	this.pic_ragli.setTransform(486.5,479,1,1,0,0,0,122.5,72);
	new cjs.ButtonHelper(this.pic_ragli, 0, 1, 1);

	this.pic_eisouf = new lib.pic_eisouf();
	this.pic_eisouf.name = "pic_eisouf";
	this.pic_eisouf.parent = this;
	this.pic_eisouf.setTransform(486,481,1,1,0,0,0,122,74);
	new cjs.ButtonHelper(this.pic_eisouf, 0, 1, 1);

	this.pic_medical = new lib.pic_medical();
	this.pic_medical.name = "pic_medical";
	this.pic_medical.parent = this;
	this.pic_medical.setTransform(483.5,481,1,1,0,0,0,119.7,75);
	new cjs.ButtonHelper(this.pic_medical, 0, 1, 1);

	this.pic_tech = new lib.pic_tech();
	this.pic_tech.name = "pic_tech";
	this.pic_tech.parent = this;
	this.pic_tech.setTransform(485,480.8,1,1,0,0,0,118.2,68.8);
	new cjs.ButtonHelper(this.pic_tech, 0, 1, 1);

	this.pic_logic = new lib.pic_logic();
	this.pic_logic.name = "pic_logic";
	this.pic_logic.parent = this;
	this.pic_logic.setTransform(483.6,484,1,1,0,0,0,119.6,72);
	new cjs.ButtonHelper(this.pic_logic, 0, 1, 1);

	this.pic_education = new lib.pic_education();
	this.pic_education.name = "pic_education";
	this.pic_education.parent = this;
	this.pic_education.setTransform(487.7,489,1,1,0,0,0,106.7,66);
	new cjs.ButtonHelper(this.pic_education, 0, 1, 1);

	this.pic_kesher = new lib.pic_kesher();
	this.pic_kesher.name = "pic_kesher";
	this.pic_kesher.parent = this;
	this.pic_kesher.setTransform(488,486,1,1,0,0,0,107,63);
	new cjs.ButtonHelper(this.pic_kesher, 0, 1, 1);

	this.pic_handasa = new lib.pic_handasa();
	this.pic_handasa.name = "pic_handasa";
	this.pic_handasa.parent = this;
	this.pic_handasa.setTransform(485,489.5,1,1,0,0,0,100,66.5);
	new cjs.ButtonHelper(this.pic_handasa, 0, 1, 1);

	this.more_info = new cjs.Text("", "bold 55px 'Alef'", "#E6C833");
	this.more_info.name = "more_info";
	this.more_info.textAlign = "center";
	this.more_info.lineHeight = 77;
	this.more_info.lineWidth = 381;
	this.more_info.parent = this;
	this.more_info.setTransform(484.5,199.3);

	this.h2 = new cjs.Text("עבור על גבי הסמלים או על שמות היחידות כדי לגלות עוד מידע", "50px 'Alef'", "#E6C833");
	this.h2.name = "h2";
	this.h2.textAlign = "center";
	this.h2.lineHeight = 70;
	this.h2.lineWidth = 472;
	this.h2.parent = this;
	this.h2.setTransform(488.9,298.6);

	this.h1 = new cjs.Text("חילות צה''ל", "bold 70px 'Alef'", "#E6C833");
	this.h1.name = "h1";
	this.h1.textAlign = "center";
	this.h1.lineHeight = 97;
	this.h1.lineWidth = 356;
	this.h1.parent = this;
	this.h1.setTransform(483.4,167);

	this.txt_regli = new cjs.Text("חיל הרגלים", "17px 'Alef'", "#E6C833");
	this.txt_regli.name = "txt_regli";
	this.txt_regli.textAlign = "center";
	this.txt_regli.lineHeight = 25;
	this.txt_regli.lineWidth = 141;
	this.txt_regli.parent = this;
	this.txt_regli.setTransform(879.4,689.1);

	this.ragli = new lib.tank();
	this.ragli.name = "ragli";
	this.ragli.parent = this;
	this.ragli.setTransform(878.9,703.4,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.ragli, 0, 1, 1);

	this.txt_medical = new cjs.Text("חיל הרפואה", "17px 'Alef'", "#E6C833");
	this.txt_medical.name = "txt_medical";
	this.txt_medical.textAlign = "center";
	this.txt_medical.lineHeight = 25;
	this.txt_medical.lineWidth = 126;
	this.txt_medical.parent = this;
	this.txt_medical.setTransform(84.7,688.8,1.044,1.001);

	this.txt_shalish = new cjs.Text("חיל משאבי האנוש", "17px 'Alef'", "#E6C833");
	this.txt_shalish.name = "txt_shalish";
	this.txt_shalish.textAlign = "center";
	this.txt_shalish.lineHeight = 25;
	this.txt_shalish.lineWidth = 141;
	this.txt_shalish.parent = this;
	this.txt_shalish.setTransform(83.2,758);

	this.shalish = new lib.shalish();
	this.shalish.name = "shalish";
	this.shalish.parent = this;
	this.shalish.setTransform(84.1,771.4,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.shalish, 0, 1, 1);

	this.txt_handasa = new cjs.Text("חיל ההנדסה הקרבית", "17px 'Alef'", "#E6C833");
	this.txt_handasa.name = "txt_handasa";
	this.txt_handasa.textAlign = "center";
	this.txt_handasa.lineHeight = 25;
	this.txt_handasa.lineWidth = 151;
	this.txt_handasa.parent = this;
	this.txt_handasa.setTransform(242.8,757.2);

	this.handasa = new lib.handasa();
	this.handasa.name = "handasa";
	this.handasa.parent = this;
	this.handasa.setTransform(242.9,771.1,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.handasa, 0, 1, 1);

	this.txt_tech = new cjs.Text("חיל הטכנולוגיה", "17px 'Alef'", "#E6C833");
	this.txt_tech.name = "txt_tech";
	this.txt_tech.textAlign = "center";
	this.txt_tech.lineHeight = 25;
	this.txt_tech.lineWidth = 141;
	this.txt_tech.parent = this;
	this.txt_tech.setTransform(401.1,756.4);

	this.tech = new lib.tech();
	this.tech.name = "tech";
	this.tech.parent = this;
	this.tech.setTransform(403.5,771.1,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.tech, 0, 1, 1);

	this.txt_police = new cjs.Text("חיל המשטרה הצבאית", "17px 'Alef'", "#E6C833");
	this.txt_police.name = "txt_police";
	this.txt_police.textAlign = "center";
	this.txt_police.lineHeight = 25;
	this.txt_police.lineWidth = 181;
	this.txt_police.parent = this;
	this.txt_police.setTransform(563.9,755.7);

	this.police = new lib.police();
	this.police.name = "police";
	this.police.parent = this;
	this.police.setTransform(564.1,770.8,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.police, 0, 1, 1);

	this.txt_education = new cjs.Text("חיל החינוך", "17px 'Alef'", "#E6C833");
	this.txt_education.name = "txt_education";
	this.txt_education.textAlign = "center";
	this.txt_education.lineHeight = 25;
	this.txt_education.lineWidth = 141;
	this.txt_education.parent = this;
	this.txt_education.setTransform(723.6,756.7);

	this.education = new lib.education();
	this.education.name = "education";
	this.education.parent = this;
	this.education.setTransform(721.6,770.8,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.education, 0, 1, 1);

	this.txt_kesher = new cjs.Text("חיל הקשר והתקשוב", "17px 'Alef'", "#E6C833");
	this.txt_kesher.name = "txt_kesher";
	this.txt_kesher.textAlign = "center";
	this.txt_kesher.lineHeight = 25;
	this.txt_kesher.lineWidth = 141;
	this.txt_kesher.parent = this;
	this.txt_kesher.setTransform(882.7,756.2);

	this.kesher = new lib.kesher();
	this.kesher.name = "kesher";
	this.kesher.parent = this;
	this.kesher.setTransform(881.1,770.8,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.kesher, 0, 1, 1);

	this.medical = new lib.medical();
	this.medical.name = "medical";
	this.medical.parent = this;
	this.medical.setTransform(84.9,702.9,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.medical, 0, 1, 1);

	this.txt_logic = new cjs.Text("חיל הלוגיסטיקה", "17px 'Alef'", "#E6C833");
	this.txt_logic.name = "txt_logic";
	this.txt_logic.textAlign = "center";
	this.txt_logic.lineHeight = 25;
	this.txt_logic.lineWidth = 143;
	this.txt_logic.parent = this;
	this.txt_logic.setTransform(244.9,688);

	this.logic = new lib.logic();
	this.logic.name = "logic";
	this.logic.parent = this;
	this.logic.setTransform(246.2,702.3,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.logic, 0, 1, 1);

	this.eisouf = new lib.eisouf();
	this.eisouf.name = "eisouf";
	this.eisouf.parent = this;
	this.eisouf.setTransform(404.7,703.7,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.eisouf, 0, 1, 1);

	this.txt_totah = new cjs.Text("חיל התותחנים", "17px 'Alef'", "#E6C833");
	this.txt_totah.name = "txt_totah";
	this.txt_totah.textAlign = "center";
	this.txt_totah.lineHeight = 25;
	this.txt_totah.lineWidth = 126;
	this.txt_totah.parent = this;
	this.txt_totah.setTransform(564.5,689.2,1.044,1.001);

	this.totah = new lib.totah();
	this.totah.name = "totah";
	this.totah.parent = this;
	this.totah.setTransform(564.2,703.4,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.totah, 0, 1, 1);

	this.txt_totah_1 = new cjs.Text("חיל השריון", "17px 'Alef'", "#E6C833");
	this.txt_totah_1.name = "txt_totah_1";
	this.txt_totah_1.textAlign = "center";
	this.txt_totah_1.lineHeight = 25;
	this.txt_totah_1.lineWidth = 126;
	this.txt_totah_1.parent = this;
	this.txt_totah_1.setTransform(723.5,689.2,1.044,1.001);

	this.tank = new lib.tank();
	this.tank.name = "tank";
	this.tank.parent = this;
	this.tank.setTransform(721.7,703.4,1,1,0,0,0,74.2,23.2);
	new cjs.ButtonHelper(this.tank, 0, 1, 1);

	this.btn_handasa = new lib.btn_handasa();
	this.btn_handasa.name = "btn_handasa";
	this.btn_handasa.parent = this;
	this.btn_handasa.setTransform(779,246,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_handasa, 0, 1, 1);

	this.btn_tech = new lib.btn_tech();
	this.btn_tech.name = "btn_tech";
	this.btn_tech.parent = this;
	this.btn_tech.setTransform(583,67,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_tech, 0, 1, 1);

	this.btn_logic = new lib.btn_logic();
	this.btn_logic.name = "btn_logic";
	this.btn_logic.parent = this;
	this.btn_logic.setTransform(373,70,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_logic, 0, 1, 1);

	this.btn_shalish = new lib.btn_shalish();
	this.btn_shalish.name = "btn_shalish";
	this.btn_shalish.parent = this;
	this.btn_shalish.setTransform(232,135,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_shalish, 0, 1, 1);

	this.btn_education = new lib.btn_education();
	this.btn_education.name = "btn_education";
	this.btn_education.parent = this;
	this.btn_education.setTransform(164,246,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_education, 0, 1, 1);

	this.btn_kesher = new lib.btn_kesher();
	this.btn_kesher.name = "btn_kesher";
	this.btn_kesher.parent = this;
	this.btn_kesher.setTransform(641,626,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_kesher, 0, 1, 1);

	this.btn_totah = new lib.btn_totah();
	this.btn_totah.name = "btn_totah";
	this.btn_totah.parent = this;
	this.btn_totah.setTransform(757,549,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_totah, 0, 1, 1);

	this.btn_tank = new lib.btn_tank();
	this.btn_tank.name = "btn_tank";
	this.btn_tank.parent = this;
	this.btn_tank.setTransform(356.3,631.5,1,1,0,0,0,29,29);
	new cjs.ButtonHelper(this.btn_tank, 0, 1, 1);

	this.btn_ragli = new lib.btn_ragli();
	this.btn_ragli.name = "btn_ragli";
	this.btn_ragli.parent = this;
	this.btn_ragli.setTransform(224,549,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_ragli, 0, 1, 1);

	this.btn_police = new lib.btn_police();
	this.btn_police.name = "btn_police";
	this.btn_police.parent = this;
	this.btn_police.setTransform(158,394,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_police, 0, 1, 1);

	this.btn_medical = new lib.btn_medical();
	this.btn_medical.name = "btn_medical";
	this.btn_medical.parent = this;
	this.btn_medical.setTransform(707,125,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_medical, 0, 1, 1);

	this.btn_eisouf = new lib.btn_eisouf();
	this.btn_eisouf.name = "btn_eisouf";
	this.btn_eisouf.parent = this;
	this.btn_eisouf.setTransform(807,393,1,1,0,0,0,30,30);
	new cjs.ButtonHelper(this.btn_eisouf, 0, 1, 1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAmDAAAQAAQsrJLyQrJL0vxAAQvvAArKr0QrJryAAwsQAAwrLJr0QLJryPwAAQPyAALILyQLJLzAAQsg");
	this.shape.setTransform(484.8,355.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666633").s().p("EgcUA/TIAAgKMgvuAAAMAAAgmCIgUAAMAAAhYZMCYtAAAMAAAB+lgEhJkA99IXLAAIAAnQI3LAAgEgXpA96IXLAAIAAnQI3LAAgEgwwA96IXLAAIAAnQI3LAAgEAy+A93IXLAAIAAnQI3LAAgEAaDA93IXLAAIAAnQI3LAAgEABbA93IXLAAIAAnQI3LAAgEgXeAzYIXLAAIAAnQI3LAAgEAaEAzVIXLAAIAAnQI3LAAgEABcAzVIXLAAIAAnQI3LAAgEhJbAzRIXLAAIAAnRI3LAAgEgwPAzLIXLAAIAAnRI3LAAgEAylAy2IV9AAIAAmzI19AAgEglZgGtQAAQqLJLzQLJL0PwAAQPxAALJr0QLJryAAwrQAAwtrJrzQrJryvxAAQvwAArJLyQrJL0AAQsIAAAAgA6QVwQrJrzAAwqQAAwsLJr0QLJryPwAAQPxAALJLyQLJLzAAQtQAAQrrJLyQrJL0vxAAQvwAArJr0gEAmsgGtIAAAAg");
	this.shape_1.setTransform(480.7,398.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.btn_eisouf},{t:this.btn_medical},{t:this.btn_police},{t:this.btn_ragli},{t:this.btn_tank},{t:this.btn_totah},{t:this.btn_kesher},{t:this.btn_education},{t:this.btn_shalish},{t:this.btn_logic},{t:this.btn_tech},{t:this.btn_handasa},{t:this.tank},{t:this.txt_totah_1},{t:this.totah},{t:this.txt_totah},{t:this.eisouf},{t:this.logic},{t:this.txt_logic},{t:this.medical},{t:this.kesher},{t:this.txt_kesher},{t:this.education},{t:this.txt_education},{t:this.police},{t:this.txt_police},{t:this.tech},{t:this.txt_tech},{t:this.handasa},{t:this.txt_handasa},{t:this.shalish},{t:this.txt_shalish},{t:this.txt_medical},{t:this.ragli},{t:this.txt_regli},{t:this.h1},{t:this.h2},{t:this.more_info},{t:this.pic_handasa},{t:this.pic_kesher},{t:this.pic_education},{t:this.pic_logic},{t:this.pic_tech},{t:this.pic_medical},{t:this.pic_eisouf},{t:this.pic_ragli},{t:this.pic_shalish},{t:this.pic_totah},{t:this.pic_police},{t:this.pic_tank},{t:this.info},{t:this.txt_eisouf}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(472,393,977.5,835.8);
// library properties:
lib.properties = {
	id: 'FCE728541ADB4973A476EE14A49E378B',
	width: 960,
	height: 800,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/RECOVER_Untitled_3_atlas_.png?1539022639121", id:"RECOVER_Untitled_3_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FCE728541ADB4973A476EE14A49E378B'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;